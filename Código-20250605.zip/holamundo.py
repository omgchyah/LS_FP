#Nuestro primer programa con Python

# Escribe en pantalla la expresión 'Hola Mundo'
print ("Hola Mundo")

input()# Esta línea permite ejecutar 'holamundo.py' en el entorno gráfico
