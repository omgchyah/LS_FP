#Variante del programa holamundo.py

print ("Hola") # Escribe en pantalla la expresión 'Hola'

print ("Mundo") # Escribe en pantalla la expresión 'Mundo'
